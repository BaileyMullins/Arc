function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);

}

function draw() {
	noFill();
	strokeWeight(15);
	stroke(239, 19, 19);
	arc(160,100,180,180,3.14,0.00);
	stroke(255, 199, 0);
	arc(160,100,150,150,3.14,0.00);
		stroke(255, 248, 50);
	arc(160,100,120,120,3.14,0.00);
		stroke(109, 239, 2);
	arc(160,100,90,90,3.14,0.00);
		stroke(2, 128, 239);
	arc(160,100,60,60,3.14,0.00);
		stroke(182, 0, 255);
	arc(160,100,30,30,3.14,0.00);
}